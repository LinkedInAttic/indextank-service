require 'net/http'
require 'uri'
require 'rubygems'
require 'json'

class IndexTank

    BASE_URL = 'http://api.indextank.com/api/v0'

    def initialize(api_key, index_name=nil)
        @api_key = api_key
        @def_index_name = index_name
    end

    def create_index(index_name=nil)
        return api_call("admin/create", index_name)
    end


    def delete_index(index_name=nil)
        return api_call("admin/delete", index_name)
    end


    def list_indexes()
        return api_call("admin/list")
    end


    def add(doc_id, content, index_name=nil)
        data = {'document' => JSON.dump(content), 'document_id' => doc_id}
        return api_call("index/add", index_name, data)
    end

    def update(doc_id, content, index_name=nil)
        data = {'document' => JSON.dump(content), 'document_id' => doc_id}
        return api_call("index/update", index_name, data)
    end


    def delete(doc_id, index_name=nil)
        data = {'document_id' => doc_id}
        return api_call("index/delete", index_name, data)
    end


    def search(query, index_name=nil, start=0, len=10)
        data = {'query' => query, 'start' => start, 'len' => len, }
        return api_call("search/query",index_name,data)
    end

       
    def index_stats(index_name=nil)
        return api_call("index/stats", index_name)
    end


    def search_stats(index_name=nil)
        return api_call("search/stats", index_name)
    end

    private

    def api_call(method, index_name=nil, params={})
        name = index_name || @def_index_name
        base_params = { 'api_key' =>  @api_key, 'index_name' => name }.merge(params)
        url = BASE_URL + '/' + method
        req = Net::HTTP::Post.new(url)
        req.set_form_data(base_params, ';')
        res = Net::HTTP.new('api.indextank.com').start {|http| http.request(req) }
        result = JSON.parse(res.body)
        ok = result['status'] == 'OK'
        return ok ? [ok, result['results']] : [ok, result['message']]
    end

end
