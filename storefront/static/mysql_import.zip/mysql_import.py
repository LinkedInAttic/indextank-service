import MySQLdb
from lib.indextank import IndexTank

###############################################################
# The results for this query will be the indexed documents
# considering the field names in the query as the field names
# for the index.
# One of the fields must have the "document_id" alias to 
# indicate that it is the DOCUMENT IDENTIFIER field.
###############################################################
SELECT_QUERY = '<QUERY>'

# Database config  
DATABASE_HOST = '<HOST>'
DATABASE_USER = '<USER>'
DATABASE_PASSWORD = '<PASS>'
DATABASE_SCHEMA = '<DATABASE>'

# IndexTank config
API_KEY = '<YOUR API KEY>'
INDEX_NAME = '<YOUR INDEX NAME>'

def get_connection():
  connection = MySQLdb.connect(host=DATABASE_HOST,
                  user=DATABASE_USER,
                  passwd=DATABASE_PASSWORD,
                  db=DATABASE_SCHEMA)
  return connection

if __name__ == "__main__":
  connection = get_connection()

  cursor = connection.cursor(MySQLdb.cursors.DictCursor)
  cursor.execute(SELECT_QUERY)

  it = IndexTank(api_key=API_KEY, index_code=INDEX_NAME)
  
  while True:
    row = cursor.fetchone()
    
    if not row:
      break
    
    if not 'document_id' in row:
      raise Exception('The select query must have ONE field named \'document_id\'')
    
    only_fields = dict((x,y) for x,y in row.items())
    del only_fields['document_id']
    
    document_id = row['document_id']
    
    print 'Indexing: ' + str(row)
    it.add(document_id, only_fields)
    
  cursor.close()
