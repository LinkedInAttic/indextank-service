IndexTank Wordpress plugin README.txt

Instructions:
* place indextank_search.php on your wp-content/plugins directory.
* place indextank.php on your wp-content/plugins directory.
* Go to the plugins section of your WP Dashboard, and activate Indextank.
* Now, you need to configure it
    * In your dashboard, go to Tools -> Indextank Searching
    * Fill your API_KEY, and your INDEX_NAME. If you don't have them yet, you
     need to get an account at http://indextank.com/
    * Press the UPDATE button to save those parameters
* After you are all set, you can press the "Index them" button on Tools ->
Indextank Searching

You are all set, now just query something on your blog sidebar.
