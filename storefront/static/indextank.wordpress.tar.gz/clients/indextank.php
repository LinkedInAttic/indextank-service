<?php

// sudo apt-get install php5 php5-curl

class IndexTank {

    /*private*/ var $api_key = NULL;
    /*private*/ var $def_index_name = NULL;

    /*private*/ var $BASE_URL = 'http://api.indextank.com/api/v0';


    /* PHP4 constructor */
    function IndexTank($api_key,$index_name=NULL){
        $this->api_key = $api_key;
        $this->def_index_name = $index_name;
    }

    /*public*/ function __construct($api_key, $index_name=NULL) {
        $this->api_key = $api_key;
        $this->def_index_name = $index_name;
    }

    /*private*/ function post($url,$params) {
        $args = '';
        $sep = '';
        foreach ($params as $key => $val) {
            $args .= $sep.$key.'='.urlencode($val);
            $sep = '&';
        }
        $session = curl_init($this->BASE_URL.'/'.$url);
        curl_setopt($session, CURLOPT_POST, true); // Tell curl to use HTTP POST
        curl_setopt($session, CURLOPT_POSTFIELDS, $args); // Tell curl that this is the body of the POST
        curl_setopt($session, CURLOPT_HEADER, false); // Tell curl not to return headers
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true); // Tell curl to return the response
        curl_setopt($session, CURLOPT_HTTPHEADER, array('Expect:')); //Fixes the HTTP/1.1 417 Expectation Failed
        $response = curl_exec($session);
        $http_code = curl_getinfo($session,CURLINFO_HTTP_CODE);
        curl_close($session); 

        if (200 == $http_code) { 
            return $response;
        } else {
            return NULL;
        }
    }

    /*private*/ function api_call($url, $index_name=NULL, $extra_params=NULL) {
        if ($index_name == NULL) $index_name = $this->def_index_name;
        $params = array('api_key'=>$this->api_key, 'index_name'=>$index_name);
        if ($extra_params) $params = array_merge($params, $extra_params);
        $json = $this->post($url, $params);
        if (NULL == $json){ // an error occurred
            $json = '{"status":"ERROR", "message": "INDEXTANK INTERNAL ERROR. RETRY IN 30 SECONDS"}';
        }
        $result = json_decode($json, true);
        return $result;
    }


    /*public*/ function create_index($index_name=NULL) {
        return $this->api_call("admin/create", $index_name);
    }

    /*public*/ function delete_index($index_name=NULL) {
        return $this->api_call("admin/delete", $index_name);
    }

    /*public*/ function list_indexes() {
        return $this->api_call("admin/list");
    }

    /*public*/ function add($doc_id, $content, $index_name=NULL) {
        $json = json_encode($content);
        return $this->api_call("index/add", $index_name, array("document_id"=>$doc_id, "document"=>$json));
    }

    /*public*/ function update($doc_id, $content, $index_name=NULL) {
        $json = json_encode($content);
        return $this->api_call("index/update", $index_name, array("document_id"=>$doc_id, "document"=>$json));
    }

    /*public*/ function delete($doc_id, $index_name=NULL) {
        return $this->api_call("index/delete", $index_name, array("document_id"=>$doc_id));
    }

    /*public*/ function index_stats($doc_id, $query, $index_name=NULL) {
        return $this->api_call("index/stats", $index_name);
    }

    /*public*/ function search($query, $index_name=NULL, $start=0, $len=10) {
        return $this->api_call("search/query", $index_name, array("query"=>$query, "start"=>$start, "len"=>$len));
    }

    /*public*/ function search_stats($doc_id, $query, $index_name=NULL) {
        return $this->api_call("search/stats", $index_name);
    }

}


