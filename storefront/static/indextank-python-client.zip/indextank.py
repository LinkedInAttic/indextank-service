import urllib
import json 

BASE_URL = 'http://api.indextank.com/api/v0'
#BASE_URL = 'http://api.it-test.flaptor.com/api/v0'


class IndexTank:

    api_key=None
    def_index_name=None


    def __init__(self, api_key, index_name=None):
        self.api_key = api_key
        self.def_index_name = index_name


    def __api_call(self, method, index_name=None, params={}):
        base_params = { 
            'api_key': self.api_key,
            'index_name': index_name or self.def_index_name,
        }
        base_params.update(params)
        params = urllib.urlencode(base_params)
        url = "%s/%s"%(BASE_URL,method)
        res = urllib.urlopen(url,params)
        data = res.read()
        if 200 != res.getcode():
            return False, 'HttpResponse code %d\nResponse contente is:\n%s' % (res.getcode(), data)
        try:
            result = json.loads(data)
        except ValueError,e:
            return False, 'Error decoding json response.\nResponse content is:\n%s' % (data)
        ok = result.get('status') == 'OK'
        return ok, result.get('results') if ok else result.get('message')

    
    def create_index(self, index_name=None):
        return self.__api_call("admin/create",index_name=index_name)


    def delete_index(self, index_name=None):
        return self.__api_call("admin/delete",index_name=index_name)


    def list_indexes(self):
        return self.__api_call("admin/list")


    def add(self, doc_id, content, index_name=None):
        data = { 'document': json.dumps(content), 'document_id': doc_id}
        return self.__api_call("index/add",index_name=index_name,params=data)


    def update(self, doc_id, content, index_name=None):
        data = { 'document': json.dumps(content), 'document_id':doc_id}
        return self.__api_call("index/update",index_name=index_name,params=data)


    def delete(self, doc_id, index_name=None):
        data = { 'document_id':doc_id}
        return self.__api_call("index/delete",index_name=index_name,params=data)


    def search(self, query, index_name=None, start=0, len=10):
        data = { 'query':query, 'start':start, 'len':len, }
        return self.__api_call("search/query",index_name=index_name,params=data)

       
    def index_stats(self, index_name=None):
        return self.__api_call("index/stats",index_name=index_name)


    def search_stats(self, index_name=None):
        return self.__api_call("search/stats",index_name=index_name)



